/* getty.c - getty - 10/12/2006
 *
 * http://unix-sys-tools.sourceforge.net
 *
 * Copyright (C) 2006, 2007 Kris Katterjohn
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

/* for getopt() */
#define _POSIX_SOURCE
#define _POSIX_C_SOURCE 2

#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#include <ctype.h>
#include <limits.h>
#include <errno.h>
#include <termios.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include <sys/utsname.h>
#include <assert.h>

/* OpenBSD (3.8, at least) apparently needs this for getopt() */
#ifdef __OpenBSD__
#include <getopt.h>
#endif

#include "basename.h"
#include "chomp.h"
#include "convertBaudRate.h"
#include "addenv.h"

/* ASCII DEL character */
#define DEL 127

/* system console to use if the environment variable "CONSOLE" doesn't exist */
#define CONSOLE "/dev/console"

/* default issue file to display */
#define ISSUE "/etc/issue"

/* default program to execute */
#define LOGIN "/bin/login"

static int ttyfd = -1;
static int consolefd = STDERR_FILENO;

/* gotta have a special die() for getty */
static void die(const char *fmt, ...)
{
	va_list ap;
	char buf[LINE_MAX];

	sprintf(buf, "getty: ");

	va_start(ap, fmt);
	vsprintf(buf + strlen(buf), fmt, ap);
	va_end(ap);

	strcat(buf, "\n");

	write(consolefd, buf, strlen(buf));

	exit(1);
}

/* write() printf()-formatted text to console (or stderr) */
static int consoleprint(const char *fmt, ...)
{
	va_list ap;
	char buf[LINE_MAX];

	sprintf(buf, "getty: ");

	va_start(ap, fmt);
	vsprintf(buf + strlen(buf), fmt, ap);
	va_end(ap);

	return write(consolefd, buf, strlen(buf));
}

/* write perror()-like message to console (or stderr) */
static void Perror(const char *str)
{
	assert(str && *str);

	consoleprint("%s: %s\n", str, strerror(errno));
}

/* write() printf()-formatted text to terminal */
static int ttyprint(const char *fmt, ...)
{
	va_list ap;
	char buf[LINE_MAX];

	assert(ttyfd != -1);

	va_start(ap, fmt);
	vsprintf(buf, fmt, ap);
	va_end(ap);

	return write(ttyfd, buf, strlen(buf));
}

static void openConsole(void)
{
	char *console = getenv("CONSOLE");

	if (!console)
		console = CONSOLE;

	if ((consolefd = open(console, O_WRONLY)) == -1)
		consolefd = STDERR_FILENO;
	else {
		int flags = fcntl(consolefd, F_GETFD);
		fcntl(consolefd, F_SETFD, flags |= FD_CLOEXEC);
	}
}

/* open /dev/<tty> */
static void openTty(const char *tty)
{
	char *term;
	int size;

	if ((size = strlen("/dev/") + strlen(tty) + 1) > 24) {
		if (size > 48)
			die("Suspiciously long tty port");
		consoleprint("Suspiciously long tty port\n");
	}

	if (!(term = malloc(size))) {
		Perror("malloc()");
		exit(1);
	}

	sprintf(term, "/dev/%s", tty);

	if ((ttyfd = open(term, O_RDWR)) == -1) {
		Perror("open(tty)");
		exit(1);
	}

	free(term);
}

/* convert letter to control characters */
#define c2cc(x) (toupper(x) - 'A' + 1)

/* setup some "sane" values for terminal */
static void setupTty(const speed_t baud)
{
	struct termios t;

	if (tcgetattr(ttyfd, &t) == -1)
		Perror("tcgetattr()");

	cfsetispeed(&t, baud);
	cfsetospeed(&t, baud);

	t.c_lflag |= ICANON | ECHO;

	t.c_cc[VINTR] = c2cc('C');
	t.c_cc[VKILL] = c2cc('U');
	t.c_cc[VSUSP] = c2cc('Z');
	t.c_cc[VEOF] = c2cc('D');
	t.c_cc[VERASE] = DEL;
	t.c_cc[VSTART] = c2cc('Q');
	t.c_cc[VSTOP] = c2cc('S');

	if (tcsetattr(ttyfd, TCSAFLUSH, &t) == -1)
		Perror("tcsetattr()");
}

#undef c2cc

/* get strftime()-formatted string */
static char *Strftime(const char *fmt)
{
	static char datetime[32];
	time_t t;
	struct tm *tm;

	t = time(0);
	tm = localtime(&t);

	strftime(datetime, 32, fmt, tm);

	return datetime;
}

/* parse and display issue file */
static void printIssue(const char *issue, const speed_t baud, const char *tty)
{
	FILE *f;
	char line[LINE_MAX], *p;
	struct utsname uts;

	if (uname(&uts) == -1)
		return;

	if (!(f = fopen(issue, "r")))
		return;

	while (fgets(line, sizeof line, f)) {
		for (p = line; *p; p++) {
			if (*p == '\\') {
				switch (*++p) {
				case '\\':
					ttyprint("\\");
					break;
				case 'b':
					ttyprint("%d", (int) baud);
					break;
				case 'd':
					ttyprint("%s", Strftime("%F"));
					break;
				case 's':
					ttyprint("%s", uts.sysname);
					break;
				case 'l':
					ttyprint("%s", tty);
					break;
				case 'm':
					ttyprint("%s", uts.machine);
					break;
				case 'n':
					ttyprint("%s", uts.nodename);
					break;
				case 'r':
					ttyprint("%s", uts.release);
					break;
				case 't':
					ttyprint("%s", Strftime("%T"));
					break;
#if 0
				/* not implemented yet */
				case 'u':
					/* # users logged in */
					break;
				case 'U':
					/* "`# users logged in` (user|users)" */
					break;
#endif
				case 'v':
					ttyprint("%s", uts.version);
					break;
				default:
					ttyprint("\\%c", *p);
					break;
				}
			} else {
				ttyprint("%c", *p);
			}
		}
	}

	fclose(f);
}

/* read username from terminal */
static void getLoginName(char *namebuf, const size_t len)
{
	do {
		ttyprint("Login: ");
	} while (read(ttyfd, namebuf, len) <= 0);

	chomp(namebuf);
}

int main(int argc, char *argv[])
{
	int c;
	int noauth = 0, noissue = 0;
	speed_t baud, realbaud;
	char *issue = NULL;
	char *loginprog, *tty;
	char namebuf[128];

	while ((c = getopt(argc, argv, "f:il:ns:")) != -1) {
		switch (c) {
		case 'f':
			issue = optarg;
			break;
		case 'i':
			noissue = 1;
			break;
		case 'l':
			loginprog = optarg;
			break;
		case 'n':
			noauth = 1;
			break;
		case 's':
			/* basically "-s <x>" == "-inl <x>" */
			noauth = noissue = 1;
			loginprog = optarg;
			break;
		default:
			break;
		}
	}

	if (!issue)
		issue = ISSUE;

	if (!loginprog)
		loginprog = LOGIN;

	openConsole();

	/* can we execute the (possibly) user-supplied program? */
	if (access(loginprog, X_OK) == -1) {
		Perror("access()");
		return 1;
	}

	/* get tty port */
	if (optind == argc)
		die("No tty port, baud rate or TERM given");

	tty = argv[optind++];

	/* get baud rate */
	if (optind == argc)
		die("No baud rate or TERM given");

	realbaud = (speed_t) atoi(argv[optind++]);

	baud = convertBaudRate(realbaud);

	if (baud == INVALSPEED)
		die("Invalid baud rate");

	/* get/set TERM */
	if (optind < argc)
		addenv("TERM", argv[optind]);

	openTty(tty);

	setupTty(baud);

	if (!noissue)
		printIssue(issue, realbaud, tty);

	if (!noauth)
		getLoginName(namebuf, sizeof namebuf);

	/* redirect std[in,out,err] to terminal */
	close(STDIN_FILENO);
	close(STDOUT_FILENO);
	close(STDERR_FILENO);
	dup(ttyfd);
	dup(ttyfd);
	dup(ttyfd);

	if (noauth)
		execl(loginprog, basename(loginprog), NULL);
	else
		execl(loginprog, basename(loginprog), namebuf, NULL);

	Perror("execl()");

	return 1;
}

