/* uname.c - POSIX uname - 10/12/2006
 *
 * http://unix-sys-tools.sourceforge.net
 *
 * Copyright (C) 2006, 2007 Kris Katterjohn
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

/* for getopt() */
#define _POSIX_SOURCE
#define _POSIX_C_SOURCE 2

#include <stdio.h>
#include <unistd.h>
#include <sys/utsname.h>

/* OpenBSD (3.8, at least) apparently needs this for getopt() */
#ifdef __OpenBSD__
#include <getopt.h>
#endif

#define MOPT 0x01
#define NOPT 0x02
#define ROPT 0x04
#define SOPT 0x08
#define VOPT 0x10
#define ALLOPTS (MOPT | NOPT | ROPT | SOPT | VOPT)

static void printUsage(void)
{
	fprintf(stderr, "Usage: uname [-amnrsv]\n\n");
	fprintf(stderr, "-a\tPrint all information\n");
	fprintf(stderr, "-m\tPrint hardware type\n");
	fprintf(stderr, "-n\tPrint network node name\n");
	fprintf(stderr, "-r\tPrint OS release level\n");
	fprintf(stderr, "-s\tPrint OS name\n");
	fprintf(stderr, "-v\tPrint OS version\n\n");
}

int main(int argc, char *argv[])
{
	int c, opts = 0;
	struct utsname uts;

	while ((c = getopt(argc, argv, "amnrsv")) != -1) {
		switch (c) {
		case 'a':
			opts |= ALLOPTS;
			break;
		case 'm':
			opts |= MOPT;
			break;
		case 'n':
			opts |= NOPT;
			break;
		case 'r':
			opts |= ROPT;
			break;
		case 's':
			opts |= SOPT;
			break;
		case 'v':
			opts |= VOPT;
			break;
		default:
			printUsage();
			return 1;
		}
	}

	if (!opts)
		opts |= SOPT;

	if (uname(&uts) == -1) {
		perror("uname()");
		return 1;
	}

	if (opts & SOPT)
		printf("%s ", uts.sysname);

	if (opts & NOPT)
		printf("%s ", uts.nodename);

	if (opts & ROPT)
		printf("%s ", uts.release);

	if (opts & VOPT)
		printf("%s ", uts.version);

	if (opts & MOPT)
		printf("%s", uts.machine);

	putchar('\n');

	return 0;
}

