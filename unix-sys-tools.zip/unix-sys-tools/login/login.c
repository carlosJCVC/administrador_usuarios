/* login.c - login - 10/15/2006
 *
 * http://unix-sys-tools.sourceforge.net
 *
 * Copyright (C) 2006, 2007 Kris Katterjohn
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

/* for crypt() (NetBSD and SunOS apparently need this set >= 4) */
#define _XOPEN_SOURCE 4

/* (Dragonfly|Free|Net|Open)BSD, BSD/OS, and Mac OS X use the getpw*() functions
 * to return the encrypted passwords instead of the getsp*() functions when
 * shadowing is used. You just have to be root (or sometimes be in the _shadow
 * group) to get it
 */
#if defined __FreeBSD__ || defined __NetBSD__ || defined __OpenBSD__ || \
    defined __DragonFly__ || defined __bsdi__ || defined __APPLE__
#ifndef NOSHADOWH
#define NOSHADOWH
#endif
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <limits.h>
#include <pwd.h>

#ifndef NOSHADOWH
#include <shadow.h>
#endif

/* SunOS apparently needs this for crypt() */
#if defined sun || defined __sun || defined __sun__
#include <crypt.h>
#endif

#include "basename.h"
#include "chomp.h"
#include "chownTty.h"
#include "die.h"
#include "addenv.h"
#include "getPassword.h"
#include "loginShell.h"
#include "warn.h"

/* if this file exists, only root can log in */
#define NOLOGIN "/etc/nologin"

/* we display the contents of this file before we exec() the shell */
#define MOTD "/etc/motd"

/* if this file exists in the user's login dir, we don't print MOTD */
#define HUSHLOGIN ".hushlogin"

/* read username from stdin */
static void getLoginName(char *namebuf, const size_t len)
{
	do {
		printf("Login: ");
		fflush(stdout);
	} while (read(STDIN_FILENO, namebuf, len) <= 0);

	chomp(namebuf);
}

/* print file to stdout */
static void displayFile(const char *file)
{
	FILE *f;
	char buf[LINE_MAX];

	if (!(f = fopen(file, "r"))) {
		perror("fopen()");
		return;
	}

	while (fgets(buf, sizeof buf, f))
		printf("%s\n", buf);

	fclose(f);
}

/* check for existence of /etc/motd and $HOME/.hushlogin */
static int hushlogin(char *home)
{
	char hush[64];

	if (access(MOTD, R_OK))
		return 1;

	if (strlen(home) + 1 + strlen(HUSHLOGIN) + 1 > sizeof hush)
		return 1;

	sprintf(hush, "%s/%s", home, HUSHLOGIN);

	return !access(hush, F_OK);
}

int main(int argc, char *argv[])
{
	int c;
	char loginname[128], password[128];
	char *stored;
	struct passwd *pwd;
#ifndef NOSHADOWH
	struct spwd *spwd;
#endif

	if (argc > 1)
		strncpy(loginname, argv[1], sizeof loginname);
	else
		getLoginName(loginname, sizeof loginname);

	for (c = 0; c < 3; c++) {
		if (c)
			getLoginName(loginname, sizeof loginname);

		if (!(pwd = getpwnam(loginname))) {
			/* We prompt for a password so the user doesn't
			 * know whether the name or password is wrong
			 */
			getPassword("Password:", password, sizeof password);
			warn("\nLogin incorrect\n");
			continue;
		}

#ifndef NOSHADOWH
		if (!(spwd = getspnam(pwd->pw_name)))
			stored = pwd->pw_passwd;
		else
			stored = spwd->sp_pwdp;
#else
		/* If we're not using shadow passwords or we're running on a BSD */
		stored = pwd->pw_passwd;
#endif

		/* Don't prompt if there's not a password */
		if (strlen(stored)) {
			getPassword("Password:", password, sizeof password);

			if (strcmp(crypt(password, stored), stored)) {
				warn("\nLogin incorrect\n");
				continue;
			}
		}

		goto authd;
	}

	/* all attempts failed */

	die("\nLogin incorrect\n");

authd:
	if (pwd->pw_uid && !access(NOLOGIN, F_OK)) {
		if (!access(NOLOGIN, R_OK))
			displayFile(NOLOGIN);
		return 1;
	}

	chownTty(pwd->pw_uid, pwd->pw_gid);

	if (setgid(pwd->pw_gid) == -1)
		perror("setgid()");

	if (setuid(pwd->pw_uid) == -1)
		perror("setuid()");

	if (!strlen(pwd->pw_shell))
		pwd->pw_shell = "/bin/sh";

	if (access(pwd->pw_dir, F_OK)) {
		warn("Home directory unavailable, using HOME=/\n");
		pwd->pw_dir = "/";
	}

	if (chdir(pwd->pw_dir) == -1)
		perror("chdir()");

	if (!hushlogin(pwd->pw_dir))
		displayFile(MOTD);

	addenv("HOME", pwd->pw_dir);
	addenv("LOGNAME", pwd->pw_name);
	addenv("USER", pwd->pw_name);
	addenv("SHELL", pwd->pw_shell);

	execl(pwd->pw_shell, loginShell(basename(pwd->pw_shell)), NULL);

	perror("execl(shell)");

	return 1;
}

