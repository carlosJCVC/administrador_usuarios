/* stty.c - stty - 10/4/2006
 *
 * http://unix-sys-tools.sourceforge.net
 *
 * Copyright (C) 2006, 2007 Kris Katterjohn
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

#define _POSIX_SOURCE

#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <termios.h>
#include <assert.h>

#include "convertBaudRate.h"
#include "die.h"

#if defined _POSIX_VDISABLE && (_POSIX_VDISABLE != -1)
#define HAVE_POSIX_VDISABLE
#endif

/* ASCII DEL character */
#define DEL 127

static char **gargv;
static int gargc;

/* try to convert letter to control characters */
#define c2cc(x) (toupper(x) - 'A' + 1)

static cc_t convertToControlChar(const char c)
{
	if (iscntrl(c2cc(c)))
		return (cc_t) c2cc(c);

	switch (c) {
	case '[':
	case '\\':
	case ']':
	case '^':
	case '_':
		assert(iscntrl(c - '[' + 27));
		return (cc_t) c - '[' + 27;
	case '?':
		return (cc_t) DEL;
	default:
		break;
	}

	return (cc_t) 0;
}

/* try to get the "visual form" of a control char */
static char *convertFromControlChar(const cc_t c)
{
	static char cc[8];

	cc[0] = cc[1] = cc[2] = cc[3] = cc[4] = cc[5] = cc[6] = cc[7] = 0;

	if (isalpha(c + 'A' - 1))
		sprintf(cc, "^%c", c + 'A' - 1);
	else if (c >= 27 && c <= 31)
		sprintf(cc, "^%c", c + '[' - 27);
	else if (c == DEL)
		sprintf(cc, "^?");
#ifdef HAVE_POSIX_VDISABLE
	else if (c == _POSIX_VDISABLE)
		sprintf(cc, "<undef>");
#endif
	else
		cc[0] = (char) c;

	return cc;
}

/* check for opt in command-line arguments */
static int checkParm(const char *opt)
{
	int i;

	for (i = 1; i < gargc; i++)
		if (!strcmp(gargv[i], opt))
			return i;
	return 0;
}

/* sopt must be in form -option */
static void setBit(const char *sopt, const tcflag_t topt, tcflag_t *t)
{
	if (checkParm(sopt)) /* -option */
		*t &= ~topt;
	else if (checkParm(sopt + 1)) /* option */
		*t |= topt;
}

static void setByteSize(tcflag_t *cflag)
{
	if (checkParm("cs5")) {
		*cflag &= ~CSIZE;
		*cflag |= CS5;
	} else if (checkParm("cs6")) {
		*cflag &= ~CSIZE;
		*cflag |= CS6;
	} else if (checkParm("cs7")) {
		*cflag &= ~CSIZE;
		*cflag |= CS7;
	} else if (checkParm("cs8")) {
		*cflag &= ~CSIZE;
		*cflag |= CS8;
	}
}

#ifdef CRDLY
static void setCrdly(tcflag_t *oflag)
{
	if (checkParm("cr0")) {
		*oflag &= ~CRDLY;
		*oflag |= CR0;
	} else if (checkParm("cr1")) {
		*oflag &= ~CRDLY;
		*oflag |= CR1;
	} else if (checkParm("cr2")) {
		*oflag &= ~CRDLY;
		*oflag |= CR2;
	} else if (checkParm("cr3")) {
		*oflag &= ~CRDLY;
		*oflag |= CR3;
	}
}
#endif

#ifdef NLDLY
static void setNldly(tcflag_t *oflag)
{
	if (checkParm("nl0")) {
		*oflag &= ~NLDLY;
		*oflag |= NL0;
	} else if (checkParm("nl1")) {
		*oflag &= ~NLDLY;
		*oflag |= NL1;
	}
}
#endif

#ifdef TABDLY
static void setTabdly(tcflag_t *oflag)
{
	if (checkParm("tabs") || checkParm("tab0")) {
		*oflag &= ~TABDLY;
		*oflag |= TAB0;
	} else if (checkParm("tab1")) {
		*oflag &= ~TABDLY;
		*oflag |= TAB1;
	} else if (checkParm("tab2")) {
		*oflag &= ~TABDLY;
		*oflag |= TAB2;
	} else if (checkParm("-tabs") || checkParm("tab3")) {
		*oflag &= ~TABDLY;
		*oflag |= TAB3;
	}
}
#endif

#ifdef BSDLY
static void setBsdly(tcflag_t *oflag)
{
	if (checkParm("bs0")) {
		*oflag &= ~BSDLY;
		*oflag |= BS0;
	} else if (checkParm("bs1")) {
		*oflag &= ~BSDLY;
		*oflag |= BS1;
	}
}
#endif

#ifdef FFDLY
static void setFfdly(tcflag_t *oflag)
{
	if (checkParm("ff0")) {
		*oflag &= ~FFDLY;
		*oflag |= FF0;
	} else if (checkParm("ff1")) {
		*oflag &= ~FFDLY;
		*oflag |= FF1;
	}
}
#endif

#ifdef VTDLY
static void setVtdly(tcflag_t *oflag)
{
	if (checkParm("vt0")) {
		*oflag &= ~VTDLY;
		*oflag |= VT0;
	} else if (checkParm("vt1")) {
		*oflag &= ~VTDLY;
		*oflag |= VT1;
	}
}
#endif

static speed_t b2termspeed(const speed_t speed)
{
	switch (speed) {
	case B0:
		return 0;
	case B50:
		return 50;
	case B75:
		return 75;
	case B110:
		return 110;
	case B134:
		return 134;
	case B150:
		return 150;
	case B200:
		return 200;
	case B300:
		return 300;
	case B600:
		return 600;
	case B1200:
		return 1200;
	case B1800:
		return 1800;
	case B2400:
		return 2400;
	case B4800:
		return 4800;
	case B9600:
		return 9600;
	case B19200:
		return 19200;
	case B38400:
		return 38400;
#ifdef B57600
	case B57600:
		return 57600;
#endif
#ifdef B115200
	case B115200:
		return 115200;
#endif
#ifdef B230400
	case B230400:
		return 230400;
#endif
#ifdef B460800
	case B460800:
		return 460800;
#endif
#ifdef B500000
	case B500000:
		return 500000;
#endif
#ifdef B576000
	case B576000:
		return 576000;
#endif
#ifdef B921600
	case B921600:
		return 921600;
#endif
#ifdef B1000000
	case B1000000:
		return 1000000;
#endif
#ifdef B1152000
	case B1152000:
		return 1152000;
#endif
#ifdef B1500000
	case B1500000:
		return 1500000;
#endif
#ifdef B2000000
	case B2000000:
		return 2000000;
#endif
#ifdef B2500000
	case B2500000:
		return 2500000;
#endif
#ifdef B3000000
	case B3000000:
		return 3000000;
#endif
#ifdef B3500000
	case B3500000:
		return 3500000;
#endif
#ifdef B4000000
	case B4000000:
		return 4000000;
#endif
	default:
		return 0;
	}
}

/* try to set input and output speeds */
static void setSpeed(struct termios *t)
{
	int i;
	speed_t speed, ispeed = INVALSPEED, ospeed = INVALSPEED;

	for (i = 1; i < gargc; i++) {
		if (!strcmp(gargv[i], "134.5")) /* hack */
			speed = (speed_t) 134;
		else if (strspn(gargv[i], "0123456789") != strlen(gargv[i]))
			continue;
		else
			speed = (speed_t) atoi(gargv[i]);

		if (!strcmp(gargv[i - 1], "ispeed"))
			ispeed = convertBaudRate(speed);
		else if (!strcmp(gargv[i - 1], "ospeed"))
			ospeed = convertBaudRate(speed);
		else
			ispeed = ospeed = convertBaudRate(speed);
	}

	if (ispeed != INVALSPEED)
		cfsetispeed(t, ispeed);
	if (ospeed != INVALSPEED)
		cfsetospeed(t, ospeed);
}

/* ugly */
static void setControlChar(cc_t *c_cc, const int index, const char *chkstr)
{
	int argc;
	char *argv;

	if ((argc = checkParm(chkstr))) {
		argv = gargv[argc + 1];
		if (!argv)
			die("No char given for %s", chkstr);
		if (!strcmp(argv, "^-") || !strcmp(argv, "undef"))
#ifdef HAVE_POSIX_VDISABLE
			c_cc[index] = _POSIX_VDISABLE;
#else
			die("Invalid char for %s", chkstr);
#endif
		else if (strlen(argv) > 2)
			die("Invalid char for %s", chkstr);
		else if (strlen(argv) == 1)
			c_cc[index] = (cc_t) argv[0];
		else if (argv[0] == '^') {
			cc_t c = convertToControlChar(argv[1]);
			if (c)
				c_cc[index] = c;
		}
	}
}

static void inputModes(struct termios *termios)
{
	setBit("-ignbrk", IGNBRK, &termios->c_iflag);

	setBit("-brkint", BRKINT, &termios->c_iflag);

	setBit("-ignpar", IGNPAR, &termios->c_iflag);

	setBit("-parmrk", PARMRK, &termios->c_iflag);

	setBit("-inpck", INPCK, &termios->c_iflag);

	setBit("-istrip", ISTRIP, &termios->c_iflag);

	setBit("-inlcr", INLCR, &termios->c_iflag);

	setBit("-igncr", IGNCR, &termios->c_iflag);

	setBit("-icrnl", ICRNL, &termios->c_iflag);

#ifdef IUCLC
	setBit("-iuclc", IUCLC, &termios->c_iflag);
#endif

#ifdef IMAXBEL
	setBit("-imaxbel", IMAXBEL, &termios->c_iflag);
#endif

	setBit("-ixon", IXON, &termios->c_iflag);

	setBit("-ixoff", IXOFF, &termios->c_iflag);

#ifdef IXANY
	setBit("-ixany", IXANY, &termios->c_iflag);
#endif

#ifdef IUTF8
	setBit("-iutf8", IUTF8, &termios->c_iflag);
#endif
}

static void outputModes(struct termios *termios)
{
	setBit("-opost", OPOST, &termios->c_oflag);

#ifdef OLCUC
	setBit("-olcuc", OLCUC, &termios->c_oflag);
#endif

#ifdef OCRNL
	setBit("-ocrnl", OCRNL, &termios->c_oflag);
#endif

#ifdef ONOCR
	setBit("-onocr", ONOCR, &termios->c_oflag);
#endif

#ifdef ONLRET
	setBit("-onlret", ONLRET, &termios->c_oflag);
#endif

#ifdef OFILL
	setBit("-ofill", OFILL, &termios->c_oflag);
#endif

#ifdef OFDEL
	setBit("-ofdel", OFDEL, &termios->c_oflag);
#endif

#ifdef CRDLY
	setCrdly(&termios->c_oflag);
#endif

#ifdef NLDLY
	setNldly(&termios->c_oflag);
#endif

#ifdef TABDLY
	setTabdly(&termios->c_oflag);
#endif

#ifdef BSDLY
	setBsdly(&termios->c_oflag);
#endif

#ifdef FFDLY
	setFfdly(&termios->c_oflag);
#endif

#ifdef VTDLY
	setVtdly(&termios->c_oflag);
#endif
}

static void controlModes(struct termios *termios)
{
	setBit("-clocal", CLOCAL, &termios->c_cflag);

	setBit("-cread", CREAD, &termios->c_cflag);

	setBit("-cstopb", CSTOPB, &termios->c_cflag);

	setBit("-hupcl", HUPCL, &termios->c_cflag);

	setBit("-hup", HUPCL, &termios->c_cflag);

	setBit("-parenb", PARENB, &termios->c_cflag);

	setBit("-parodd", PARODD, &termios->c_cflag);

	setByteSize(&termios->c_cflag);

	setSpeed(termios);
}

static void localModes(struct termios *termios)
{
	setBit("-echo", ECHO, &termios->c_lflag);

	setBit("-echoe", ECHOE, &termios->c_lflag);

	setBit("-echok", ECHOK, &termios->c_lflag);

	setBit("-echonl", ECHONL, &termios->c_lflag);

#ifdef ECHOCTL
	setBit("-echoctl", ECHOCTL, &termios->c_lflag);
#endif

#ifdef ECHOPRT
	setBit("-echoprt", ECHOPRT, &termios->c_lflag);
#endif

#ifdef ECHOKE
	setBit("-echoke", ECHOKE, &termios->c_lflag);
#endif

#ifdef XCASE
	setBit("-xcase", XCASE, &termios->c_lflag);
#endif

	setBit("-icanon", ICANON, &termios->c_lflag);

	setBit("-isig", ISIG, &termios->c_lflag);

	setBit("-noflsh", NOFLSH, &termios->c_lflag);

	setBit("-tostop", TOSTOP, &termios->c_lflag);

	setBit("-iexten", IEXTEN, &termios->c_lflag);

#ifdef FLUSHO
	setBit("-flusho", FLUSHO, &termios->c_lflag);
#endif

#ifdef PENDIN
	setBit("-pendin", PENDIN, &termios->c_lflag);
#endif
}

static void controlChars(struct termios *termios)
{
	int ret;

	setControlChar(termios->c_cc, VINTR, "intr");

	setControlChar(termios->c_cc, VKILL, "kill");

	setControlChar(termios->c_cc, VQUIT, "quit");

	setControlChar(termios->c_cc, VSUSP, "susp");

	setControlChar(termios->c_cc, VERASE, "erase");

#ifdef VWERASE
	setControlChar(termios->c_cc, VWERASE, "werase");
#endif

#ifdef VLNEXT
	setControlChar(termios->c_cc, VLNEXT, "lnext");
#endif

#ifdef VREPRINT
	setControlChar(termios->c_cc, VREPRINT, "reprint");
#endif

#ifdef VDISCARD
	setControlChar(termios->c_cc, VDISCARD, "discard");
#endif

#ifdef VSWTC
	setControlChar(termios->c_cc, VSWTC, "swtc");
#endif

	setControlChar(termios->c_cc, VEOF, "eof");

	setControlChar(termios->c_cc, VEOL, "eol");

#ifdef VEOL2
	setControlChar(termios->c_cc, VEOL2, "eol2");
#endif

	setControlChar(termios->c_cc, VSTART, "start");

	setControlChar(termios->c_cc, VSTOP, "stop");

	if ((ret = checkParm("min"))) {
		if (!gargv[ret + 1])
			die("No MIN given");
		termios->c_cc[VMIN] = (cc_t) atoi(gargv[ret + 1]);
	}

	if ((ret = checkParm("time"))) {
		if (!gargv[ret + 1])
			die("No TIME given");
		termios->c_cc[VTIME] = (cc_t) atoi(gargv[ret + 1]);
	}
}

/* set values using shorter names */
static void combinations(struct termios *termios)
{
	if (checkParm("evenp") || checkParm("parity")) {
		termios->c_cflag &= ~CSIZE;
		termios->c_cflag |= CS7;
		termios->c_iflag &= ~PARODD;
		termios->c_iflag |= PARENB;
	}
	if (checkParm("oddp")) {
		termios->c_cflag &= ~CSIZE;
		termios->c_cflag |= CS7;
		termios->c_iflag |= (PARODD | PARENB);
	}
	if (checkParm("-evenp") || checkParm("-parity") || checkParm("-oddp")) {
		termios->c_cflag &= ~CSIZE;
		termios->c_cflag |= CS8;
		termios->c_iflag &= ~PARENB;
	}
	if (checkParm("raw")) {
		termios->c_cflag &= ~CSIZE;
		termios->c_cflag |= CS8;
		termios->c_iflag &= ~INPCK;
		termios->c_oflag &= ~OPOST;
#ifdef HAVE_POSIX_VDISABLE
		termios->c_cc[VERASE] = termios->c_cc[VINTR] = _POSIX_VDISABLE;
		termios->c_cc[VKILL] = termios->c_cc[VQUIT] = _POSIX_VDISABLE;
		termios->c_cc[VEOF] = termios->c_cc[VEOL] = _POSIX_VDISABLE;
#endif
	}
	if (checkParm("-raw") || checkParm("cooked")) {
		termios->c_iflag |= INPCK;
		termios->c_cc[VINTR] = convertToControlChar('c');
		termios->c_cc[VEOF] = convertToControlChar('d');
		termios->c_cc[VEOL] = convertToControlChar('j');
		termios->c_cc[VKILL] = convertToControlChar('u');
		termios->c_cc[VERASE] = convertToControlChar('?');
		termios->c_cc[VQUIT] = convertToControlChar('\\');
	}
	if (checkParm("nl"))
		termios->c_iflag &= ~ICRNL;
	if (checkParm("-nl")) {
		termios->c_iflag |= ICRNL;
		termios->c_iflag &= ~(INLCR | IGNCR);
	}
}

/* print some "important" values */
static void printDefault(const struct termios *termios)
{
	speed_t ispeed, ospeed;

	ispeed = b2termspeed(cfgetispeed(termios));
	ospeed = b2termspeed(cfgetospeed(termios));

	/* terminal speeds */

	if (ispeed == ospeed)
		printf("speed %d baud; ", (int) ispeed);
	else
		printf("ispeed %d baud; ospeed %d baud; ", (int) ispeed, (int) ospeed);

	puts("");

	/* input modes */

	if (!(termios->c_iflag & ISTRIP))
		putchar('-');
	printf("istrip ");

	if (!(termios->c_iflag & IXON))
		putchar('-');
	printf("ixon ");

#ifdef IXANY
	if (!(termios->c_iflag & IXANY))
		putchar('-');
	printf("ixany ");
#endif

	if (!(termios->c_iflag & IXOFF))
		putchar('-');
	printf("ixoff ");

#ifdef IUTF8
	if (!(termios->c_iflag & IUTF8))
		putchar('-');
	printf("iutf8 ");
#endif

	puts("");

	/* output modes */

	if (!(termios->c_oflag & OPOST))
		putchar('-');
	printf("opost ");

	puts("");

	/* local modes */

	if (!(termios->c_lflag & ISIG))
		putchar('-');
	printf("isig ");

	if (!(termios->c_lflag & ICANON))
		putchar('-');
	printf("icanon ");

	if (!(termios->c_lflag & ECHO))
		putchar('-');
	printf("echo ");

	if (!(termios->c_lflag & TOSTOP))
		putchar('-');
	printf("tostop ");

	puts("");

	/* control modes */

	if ((termios->c_cflag & CSIZE) == CS5)
		printf("cs5 ");
	else if ((termios->c_cflag & CSIZE) == CS6)
		printf("cs6 ");
	else if ((termios->c_cflag & CSIZE) == CS7)
		printf("cs7 ");
	else if ((termios->c_cflag & CSIZE) == CS8)
		printf("cs8 ");

	if (!(termios->c_cflag & HUPCL))
		putchar('-');
	printf("hupcl ");

	puts("");

	/* control characters */

	printf("intr = %s; ", convertFromControlChar(termios->c_cc[VINTR]));

	printf("kill = %s; ", convertFromControlChar(termios->c_cc[VKILL]));

	printf("quit = %s; ", convertFromControlChar(termios->c_cc[VQUIT]));

	printf("susp = %s; ", convertFromControlChar(termios->c_cc[VSUSP]));

	printf("erase = %s; ", convertFromControlChar(termios->c_cc[VERASE]));

	printf("eof = %s; ", convertFromControlChar(termios->c_cc[VEOF]));

	printf("eol = %s; ", convertFromControlChar(termios->c_cc[VEOL]));

	printf("start = %s; ", convertFromControlChar(termios->c_cc[VSTART]));

	printf("stop = %s; ", convertFromControlChar(termios->c_cc[VSTOP]));

	printf("min = %d; ", termios->c_cc[VMIN]);

	printf("time = %d; ", termios->c_cc[VTIME]);

	puts("");
}

/* print all values */
static void printEverything(const struct termios *termios)
{
	speed_t ispeed, ospeed;

	ispeed = b2termspeed(cfgetispeed(termios));
	ospeed = b2termspeed(cfgetospeed(termios));

	/* terminal speeds */

	if (ispeed == ospeed)
		printf("speed %d baud; ", (int) ispeed);
	else
		printf("ispeed %d baud; ospeed %d baud; ", (int) ispeed, (int) ospeed);

	puts("");

	/* input modes */

	if (!(termios->c_iflag & IGNBRK))
		putchar('-');
	printf("ignbrk ");

	if (!(termios->c_iflag & BRKINT))
		putchar('-');
	printf("brkint ");

	if (!(termios->c_iflag & IGNPAR))
		putchar('-');
	printf("ignpar ");

	if (!(termios->c_iflag & PARMRK))
		putchar('-');
	printf("parmrk ");

	if (!(termios->c_iflag & INPCK))
		putchar('-');
	printf("inpck ");

	if (!(termios->c_iflag & ISTRIP))
		putchar('-');
	printf("istrip ");

	if (!(termios->c_iflag & INLCR))
		putchar('-');
	printf("inlcr ");

	if (!(termios->c_iflag & IGNCR))
		putchar('-');
	printf("igncr ");

	if (!(termios->c_iflag & ICRNL))
		putchar('-');
	printf("icrnl ");

#ifdef IUCLC
	if (!(termios->c_iflag & IUCLC))
		putchar('-');
	printf("iuclc ");
#endif

#ifdef IMAXBEL
	if (!(termios->c_iflag & IMAXBEL))
		putchar('-');
	printf("imaxbel ");
#endif

	if (!(termios->c_iflag & IXON))
		putchar('-');
	printf("ixon ");

#ifdef IXANY
	if (!(termios->c_iflag & IXANY))
		putchar('-');
	printf("ixany ");
#endif

	if (!(termios->c_iflag & IXOFF))
		putchar('-');
	printf("ixoff ");

#ifdef IUTF8
	if (!(termios->c_iflag & IUTF8))
		putchar('-');
	printf("iutf8 ");
#endif

	puts("");

	/* output modes */

	if (!(termios->c_oflag & OPOST))
		putchar('-');
	printf("opost ");

#ifdef OLCUC
	if (!(termios->c_oflag & OLCUC))
		putchar('-');
	printf("olcuc ");
#endif

#ifdef OCRNL
	if (!(termios->c_oflag & OCRNL))
		putchar('-');
	printf("ocrnl ");
#endif

#ifdef ONOCR
	if (!(termios->c_oflag & ONOCR))
		putchar('-');
	printf("onocr ");
#endif

#ifdef ONLRET
	if (!(termios->c_oflag & ONLRET))
		putchar('-');
	printf("onlret ");
#endif

#ifdef OFILL
	if (!(termios->c_oflag & OFILL))
		putchar('-');
	printf("ofill ");
#endif

#ifdef OFDEL
	if (!(termios->c_oflag & OFDEL))
		putchar('-');
	printf("ofdel ");
#endif

#ifdef CRDLY
	if ((termios->c_oflag & CRDLY) == CR0)
		printf("cr0 ");
	else if ((termios->c_oflag & CRDLY) == CR1)
		printf("cr1 ");
	else if ((termios->c_oflag & CRDLY) == CR2)
		printf("cr2 ");
	else if ((termios->c_oflag & CRDLY) == CR3)
		printf("cr3 ");
#endif

#ifdef NLDLY
	if ((termios->c_oflag & NLDLY) == NL0)
		printf("nl0 ");
	else if ((termios->c_oflag & NLDLY) == NL1)
		printf("nl1 ");
#endif

#ifdef TABDLY
	if ((termios->c_oflag & TABDLY) == TAB0)
		printf("tab0 ");
	else if ((termios->c_oflag & TABDLY) == TAB1)
		printf("tab1 ");
	else if ((termios->c_oflag & TABDLY) == TAB2)
		printf("tab2 ");
	else if ((termios->c_oflag & TABDLY) == TAB3)
		printf("tab3 ");
#endif

#ifdef BSDLY
	if ((termios->c_oflag & BSDLY) == BS0)
		printf("bs0 ");
	else if ((termios->c_oflag & BSDLY) == BS1)
		printf("bs1 ");
#endif

#ifdef FFDLY
	if ((termios->c_oflag & FFDLY) == FF0)
		printf("ff0 ");
	else if ((termios->c_oflag & FFDLY) == FF1)
		printf("ff1 ");
#endif

#ifdef VTDLY
	if ((termios->c_oflag & VTDLY) == VT0)
		printf("vt0 ");
	else if ((termios->c_oflag & VTDLY) == VT1)
		printf("vt1 ");
#endif

	puts("");

	/* local modes */

	if (!(termios->c_lflag & ISIG))
		putchar('-');
	printf("isig ");

	if (!(termios->c_lflag & ICANON))
		putchar('-');
	printf("icanon ");

	if (!(termios->c_lflag & IEXTEN))
		putchar('-');
	printf("iexten ");

	if (!(termios->c_lflag & ECHO))
		putchar('-');
	printf("echo ");

	if (!(termios->c_lflag & ECHOE))
		putchar('-');
	printf("echoe ");

	if (!(termios->c_lflag & ECHOK))
		putchar('-');
	printf("echok ");

	if (!(termios->c_lflag & ECHONL))
		putchar('-');
	printf("echonl ");

#ifdef ECHOKE
	if (!(termios->c_lflag & ECHOKE))
		putchar('-');
	printf("echoke ");
#endif

#ifdef ECHOCTL
	if (!(termios->c_lflag & ECHOCTL))
		putchar('-');
	printf("echoctl ");
#endif

#ifdef ECHOPRT
	if (!(termios->c_lflag & ECHOPRT))
		putchar('-');
	printf("echoprt ");
#endif

	if (!(termios->c_lflag & NOFLSH))
		putchar('-');
	printf("noflsh ");

#ifdef FLUSHO
	if (!(termios->c_lflag & FLUSHO))
		putchar('-');
	printf("flusho ");
#endif

	if (!(termios->c_lflag & TOSTOP))
		putchar('-');
	printf("tostop ");

#ifdef PENDIN
	if (!(termios->c_lflag & PENDIN))
		putchar('-');
	printf("pendin ");
#endif

#ifdef XCASE
	if (!(termios->c_lflag & XCASE))
		putchar('-');
	printf("xcase ");
#endif

	puts("");

	/* control modes */

	if (!(termios->c_cflag & PARENB))
		putchar('-');
	printf("parenb ");

	if (!(termios->c_cflag & PARODD))
		putchar('-');
	printf("parodd ");

	if ((termios->c_cflag & CSIZE) == CS5)
		printf("cs5 ");
	else if ((termios->c_cflag & CSIZE) == CS6)
		printf("cs6 ");
	else if ((termios->c_cflag & CSIZE) == CS7)
		printf("cs7 ");
	else if ((termios->c_cflag & CSIZE) == CS8)
		printf("cs8 ");

	if (!(termios->c_cflag & HUPCL))
		putchar('-');
	printf("hupcl ");

	if (!(termios->c_cflag & CSTOPB))
		putchar('-');
	printf("cstopb ");

	if (!(termios->c_cflag & CLOCAL))
		putchar('-');
	printf("clocal ");

	if (!(termios->c_cflag & CREAD))
		putchar('-');
	printf("cread ");

	puts("");

	/* control characters */

	printf("intr = %s; ", convertFromControlChar(termios->c_cc[VINTR]));

	printf("kill = %s; ", convertFromControlChar(termios->c_cc[VKILL]));

	printf("quit = %s; ", convertFromControlChar(termios->c_cc[VQUIT]));

	printf("susp = %s; ", convertFromControlChar(termios->c_cc[VSUSP]));

	printf("erase = %s; ", convertFromControlChar(termios->c_cc[VERASE]));

#ifdef VWERASE
	printf("werase = %s; ", convertFromControlChar(termios->c_cc[VWERASE]));
#endif

#ifdef VLNEXT
	printf("lnext = %s; ", convertFromControlChar(termios->c_cc[VLNEXT]));
#endif

#ifdef VREPRINT
	printf("reprint = %s; ", convertFromControlChar(termios->c_cc[VREPRINT]));
#endif

#ifdef VDISCARD
	printf("discard = %s; ", convertFromControlChar(termios->c_cc[VDISCARD]));
#endif

#ifdef VSWTC
	printf("swtc = %s; ", convertFromControlChar(termios->c_cc[VSWTC]));
#endif

	printf("eof = %s; ", convertFromControlChar(termios->c_cc[VEOF]));

	printf("eol = %s; ", convertFromControlChar(termios->c_cc[VEOL]));

#ifdef VEOL2
	printf("eol2 = %s; ", convertFromControlChar(termios->c_cc[VEOL2]));
#endif

	printf("start = %s; ", convertFromControlChar(termios->c_cc[VSTART]));

	printf("stop = %s; ", convertFromControlChar(termios->c_cc[VSTOP]));

	printf("min = %d; ", termios->c_cc[VMIN]);

	printf("time = %d; ", termios->c_cc[VTIME]);

	puts("");
}

int main(int argc, char *argv[])
{
	struct termios termios, termios2;

	if (!isatty(STDIN_FILENO))
		die("Standard input is not a terminal");

	gargc = argc;
	gargv = argv;

	memset(&termios, 0, sizeof termios);
	memset(&termios2, 0, sizeof termios2);

	if (tcgetattr(STDIN_FILENO, &termios) == -1) {
		perror("tcgetattr()");
		return 1;
	}

	if (argc == 1) {
		printDefault(&termios);
		return 0;
	} else if (checkParm("-a")) {
		printEverything(&termios);
		return 0;
	}

	inputModes(&termios);

	outputModes(&termios);

	controlModes(&termios);

	localModes(&termios);

	controlChars(&termios);

	combinations(&termios);

	if (tcsetattr(STDIN_FILENO, TCSADRAIN, &termios) == -1) {
		perror("tcsetattr()");
		return 1;
	}

	if (tcgetattr(STDIN_FILENO, &termios2) == -1) {
		perror("tcgetattr()");
		return 1;
	}

	if (memcmp(&termios, &termios2, sizeof(struct termios)))
		die("Unable to perform all requested operations");

	return 0;
}

