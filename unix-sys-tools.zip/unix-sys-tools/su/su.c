/* su.c - su - 10/15/2006
 *
 * http://unix-sys-tools.sourceforge.net
 *
 * Copyright (C) 2006, 2007 Kris Katterjohn
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

/* for crypt() (NetBSD and SunOS apparently need this set >= 4) */
#define _XOPEN_SOURCE 4

/* (Dragonfly|Free|Net|Open)BSD, BSD/OS, and Mac OS X use the getpw*() functions
 * to return the encrypted passwords instead of the getsp*() functions when
 * shadowing is used. You just have to be root (or sometimes be in the _shadow
 * group) to get it
 */
#if defined __FreeBSD__ || defined __NetBSD__ || defined __OpenBSD__ || \
    defined __DragonFly__ || defined __bsdi__ || defined __APPLE__
#ifndef NOSHADOWH
#define NOSHADOWH
#endif
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <grp.h>
#include <pwd.h>

#ifndef NOSHADOWH
#include <shadow.h>
#endif

/* SunOS apparently needs this for crypt() */
#if defined sun || defined __sun || defined __sun__
#include <crypt.h>
#endif

#include "addenv.h"
#include "dalloc.h"
#include "die.h"
#include "getPassword.h"
#include "Strdup.h"
#include "warn.h"

#include "log.h"
#include "suconf.h"

/* info on real uid */
char *realuserid;

#ifdef NOSHADOWH
static char *realuserpass;
#endif

static void sorry(void)
{
	die("%s", sorryMsg);
}

static void initUserid(void)
{
	struct passwd *pwd;

	if (!(pwd = getpwuid(getuid())))
		sorry();

	realuserid = Strdup(pwd->pw_name);

#ifdef NOSHADOWH
	realuserpass = Strdup(pwd->pw_passwd);
#endif
}

/* get passwd info using nam if given, else using uid and do error checking */
static struct passwd *getpwd(char *nam, const uid_t uid)
{
	struct passwd *pwd;

	errno = 0;

	if (nam) {
		if (!(pwd = getpwnam(nam))) {
			printbadlog(nam);

			if (errno)
				sorry();
			else
				die("Unknown id: %s", nam);
		}
		return pwd;
	}

	if (!(pwd = getpwuid(uid))) {
		printbadlog("root");

		if (errno)
			sorry();
		else
			die("Unknown uid: %u", (unsigned) uid);
	}

	return pwd;
}

/* not beautiful but it works */
static char **setupExecArgv(char **oargv, const int oargc, const int login)
{
	int i = 1;
	char **argv;

	/* su + oargv + NULL */
	argv = dalloc((1 + oargc + 1) * sizeof(char *));

	argv[0] = login ? "-su" : "su";

	if (oargv)
		for (; i <= oargc; i++)
			argv[i] = oargv[i - 1];

	argv[i] = NULL;

	return argv;
}

static int isInWheelGroup(void)
{
	char **mem;
	struct group *grp;

	if (!wheelGroup)
		goto allow;

	errno = 0;

	if (!(grp = getgrnam(wheelGroup))) {
		if (errno) {
			perror("getgrnam()");
			/* just to be safe */
			goto deny;
		}

		/* wheel group doesn't exist */
		goto allow;
	}

	/* wheel group is empty */
	if (!*grp->gr_mem)
		goto allow;

	for (mem = grp->gr_mem; *mem; mem++)
		if (!strcmp(*mem, realuserid))
			goto allow;

deny:
	return 0;
allow:
	return 1;
}

int main(int argc, char *argv[])
{
	int login = 0;
	int inWheel = 0;
	char *stored;
	char **argpos = NULL;
	struct passwd *pwd;
#ifndef NOSHADOWH
	struct spwd *spwd;
#endif

	if (argc > 1) {
		argpos = &argv[1];

		if (argpos[0][0] == '-') {
			if (!strcmp(argpos[0], "-")) {
				login = 1;

				argpos++;
				argc--;

				if (argpos[0] && argpos[0][0] != '-') {
					targetuser = argpos[0];
					argpos++;
					argc--;
				}
			}
		} else {
			targetuser = argpos[0];
			argpos++;
			argc--;
		}
	}

	parseSuconf();

	if (banner)
		printf("%s\n", banner);

	/* this has to be called before getpwd() because multiple calls to
	 * getpw[nam|uid]() can overwrite previous data
	 */
	initUserid();

	openlogs();

	pwd = getpwd(targetuser, (uid_t) 0);

	inWheel = isInWheelGroup();

	/* skip authentication stuff if allowed */
	if (!getuid() || (inWheel && wheelNoPass))
		goto authd;

	/* if we're trying to go root, but not in the wheel group */
	if (!pwd->pw_uid && !inWheel) {
		printbadlog(pwd->pw_name);
		sorry();
	}

	{
		int ownPass = inWheel && wheelOwnPass;
#ifndef NOSHADOWH
		if (!(spwd = getspnam(ownPass ? realuserid : pwd->pw_name)))
			sorry();
		stored = spwd->sp_pwdp;
#else
		stored = ownPass ? realuserpass : pwd->pw_passwd;
#endif
	}

	/* Don't prompt if there's not a password */
	if (strlen(stored)) {
		char password[128];

		getPassword(passprompt, password, sizeof password);

		if (strcmp(crypt(password, stored), stored)) {
			printbadlog(pwd->pw_name);
			sorry();
		}
	}

authd:
	printgoodlog(pwd->pw_name);

	if (setgid(pwd->pw_gid) == -1)
		perror("setgid()");

	if (setuid(pwd->pw_uid) == -1)
		perror("setuid()");

	if (access(pwd->pw_dir, F_OK)) {
		warn("No home directory, using HOME=/\n");
		pwd->pw_dir = "/";
	}

	if (login)
		if (chdir(pwd->pw_dir) == -1)
			perror("chdir()");

	if (!strlen(pwd->pw_shell)) {
		if (!defaultShell)
			defaultShell = "/bin/sh";
		pwd->pw_shell = defaultShell;
	}

	addenv("PATH", getuid() ? envpath : envsupath);
	addenv("HOME", pwd->pw_dir);
	addenv("LOGNAME", pwd->pw_name);
	addenv("USER", pwd->pw_name);
	addenv("SHELL", pwd->pw_shell);

	closelogs();

	cleanSuconf();

	if (setUmask)
		umask(umaskMode);

	free(realuserid);

#ifdef NOSHADOWH
	free(realuserpass);
#endif

	execv(pwd->pw_shell, setupExecArgv(argpos, argc, login));

	perror("execv(shell)");

	return 1;
}

