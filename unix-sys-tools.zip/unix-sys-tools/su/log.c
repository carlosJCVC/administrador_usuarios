/* log.c - handles logging - 10/31/2006
 *
 * http://unix-sys-tools.sourceforge.net
 *
 * Copyright (C) 2006, 2007 Kris Katterjohn
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

#define _POSIX_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/types.h>

#ifndef NOSYSLOG
#include "syslog.h"
#endif

#include "warn.h"

#include "su.h"
#include "suconf.h"

static FILE *sulog;

void openlogs(void)
{
	if (!sulogFile)
		return;

	if (!(sulog = fopen(sulogFile, "a")))
		warn("couldn't open sulog %s\n", sulogFile);
}

void closelogs(void)
{
	if (sulog)
		fclose(sulog);
}

/* this prints an entry in sulog/syslog that looks something like this:
 *
 * SU 10/31 10:56:32 + pts/0 kjak-root
 */
static void printlog(const char succ, const char *towho)
{
	char *tty;

#ifndef NOSYSLOG
	if (!sulog && !useSyslog)
#else
	if (!sulog)
#endif
		return;

	if (logBadOnly && succ == '+')
		return;

	if (!(tty = ttyname(STDIN_FILENO))) {
		tty = "none";
	} else {
		/* skip past /dev/ which should be there */
		if (!strncmp(tty, "/dev/", 5))
			tty += 5;
	}

#ifndef NOSYSLOG
	if (useSyslog) {
#ifdef LOG_AUTHPRIV
		int priority = LOG_AUTHPRIV;
#else
		int priority = LOG_AUTH;
#endif

		priority |= (succ == '+') ? LOG_INFO : LOG_ERR;

		syslog(priority, "SU %c %s %s-%s\n", succ, tty, realuserid, towho);
	}
#endif

	if (sulog) {
		time_t timet = time(NULL);
		char tbuf[16];

		strftime(tbuf, sizeof tbuf, "%m/%d %H:%M:%S", localtime(&timet));

		fprintf(sulog, "SU %s %c %s %s-%s\n", tbuf, succ, tty, realuserid, towho);
	}
}

void printbadlog(const char *towho)
{
	printlog('-', towho);
}

void printgoodlog(const char *towho)
{
	printlog('+', towho);
}

