/* suconf.c - parses su.conf file - 10/31/2006
 *
 * http://unix-sys-tools.sourceforge.net
 *
 * Copyright (C) 2006, 2007 Kris Katterjohn
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

#define _POSIX_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>

#include "chomp.h"
#include "dalloc.h"
#include "Strdup.h"
#include "warn.h"

#include "log.h"
#include "su.h"

/* default su.conf file */
#ifndef SUCONF
#define SUCONF "/etc/su.conf"
#endif

/* only this group is allowed to su root */
char *wheelGroup;

/* default target user */
char *targetuser;

/* shell to use when there's not one in the passwd file */
char *defaultShell = "/bin/sh";

/* password prompt */
char *passprompt = "Password:";

/* message to print when authorization fails */
char *sorryMsg = "Sorry";

/* banner displayed before prompt, etc. */
char *banner;

/* used to set $PATH for normal users */
char *envpath = "/bin:/usr/bin";

/* used to set $PATH for root */
char *envsupath = "/bin:/usr/bin:/sbin:/usr/sbin";

/* umask mode */
mode_t umaskMode;
int setUmask;

/* location of sulog */
char *sulogFile;

/* use syslog */
int useSyslog;

/* only log unsuccessful attempts */
int logBadOnly;

/* members of wheelGroup group can su root without a password */
int wheelNoPass;

/* members of wheelGroup group can su root using their own password */
int wheelOwnPass;

static char *transform(char *str)
{
	char *new, *n, *s;

	new = dalloc(strlen(str) + 1);

	for (n = new, s = str; *s; n++, s++) {
		if (*s == '\\') {
			switch (*(s + 1)) {
			case 'n':
				*n = '\n';
				s++;
				break;
			case 'r':
				*n = '\r';
				s++;
				break;
			case 't':
				*n = '\t';
				s++;
				break;
			default:
				*n = *s;
			}
		} else {
			*n = *s;
		}
	}

	return new;
}

static void applyOpt(char *str)
{
	char *var, *val;

	if (!(var = strtok(str, "=")))
		return;

	if (!(val = strtok(NULL, "")))
		return;

	chomp(val);

	if (!strcmp(var, "WHEEL")) {
		wheelGroup = Strdup(val);
	} else if (!strcmp(var, "DEFAULT_USER")) {
		if (!targetuser)
			targetuser = Strdup(val);
	} else if (!strcmp(var, "PROMPT")) {
		passprompt = transform(val);
	} else if (!strcmp(var, "SORRY")) {
		sorryMsg = transform(val);
	} else if (!strcmp(var, "SULOG")) {
		sulogFile = Strdup(val);
	} else if (!strcmp(var, "DEFAULT_SHELL")) {
		defaultShell = Strdup(val);
	} else if (!strcmp(var, "PATH")) {
		envpath = Strdup(val);
	} else if (!strcmp(var, "SUPATH")) {
		envsupath = Strdup(val);
	} else if (!strcmp(var, "BANNER")) {
		banner = transform(val);
	} else if (!strcmp(var, "UMASK")) {
		char *endptr;
		mode_t mode;

		mode = (mode_t) strtol(val, &endptr, 8);

		if (*val != '\0' && *endptr == '\0') {
			umaskMode = mode;
			setUmask = 1;
		}
	} else if (!strcmp(var, "ONLY_LOG_BAD")) {
		if (!strcmp(val, "0") || !strcmp(val, "no"))
			logBadOnly = 0;
		else
			logBadOnly = 1;
	} else if (!strcmp(var, "WHEEL_NOPASS")) {
		if (!strcmp(val, "0") || !strcmp(val, "no"))
			wheelNoPass = 0;
		else
			wheelNoPass = 1;
	} else if (!strcmp(var, "WHEEL_OWNPASS")) {
		if (!strcmp(val, "0") || !strcmp(val, "no"))
			wheelOwnPass = 0;
		else
			wheelOwnPass = 1;
	} else if (!strcmp(var, "SYSLOG")) {
		if (!strcmp(val, "0") || !strcmp(val, "no"))
			useSyslog = 0;
		else
			useSyslog = 1;
	}
}

static void applyBool(const char *str)
{
	if (!strcmp(str, "ONLY_LOG_BAD"))
		logBadOnly = 1;
	else if (!strcmp(str, "WHEEL_NOPASS"))
		wheelNoPass = 1;
	else if (!strcmp(str, "WHEEL_OWNPASS"))
		wheelOwnPass = 1;
	else if (!strcmp(str, "SYSLOG"))
		useSyslog = 1;
}

/* free memory allocated for variables from su.conf */
void cleanSuconf(void)
{
	if (wheelGroup)
		free(wheelGroup);
	if (sulogFile)
		free(sulogFile);
	if (passprompt)
		free(passprompt);
	if (banner)
		free(banner);
}

void parseSuconf(void)
{
	FILE *suconf;
	int lineno;
	char line[384];

	if (!(suconf = fopen(SUCONF, "r"))) {
		warn("couldn't open su.conf %s\n", SUCONF);
		return;
	}

	for (lineno = 1; fgets(line, sizeof line, suconf); lineno++) {
		char *p = line;

		/* skip beginning whitespace */
		if (isspace(*p))
			while (isspace(*p))
				p++;

		/* for (mostly) empty lines and comments */
		if (!*p || *p == '#')
			continue;

		if (strchr(p, '='))
			applyOpt(p);
		else
			applyBool(p);
	}

	fclose(suconf);
}

