/* passwd.c - passwd - 10/28/2006
 *
 * http://unix-sys-tools.sourceforge.net
 *
 * Copyright (C) 2006, 2007 Kris Katterjohn
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

/* for crypt() (NetBSD and SunOS apparently need this set >= 4) */
#define _XOPEN_SOURCE 4

/* for putpw*() */
#define _SVID_SOURCE

/* (Dragonfly|Free|Net|Open)BSD, BSD/OS, and Mac OS X use the getpw*() functions
 * to return the encrypted passwords instead of the getsp*() functions when
 * shadowing is used. You just have to be root (or sometimes be in the _shadow
 * group) to get it
 */
#if defined __FreeBSD__ || defined __NetBSD__ || defined __OpenBSD__ || \
    defined __DragonFly__ || defined __bsdi__ || defined __APPLE__
#ifndef NOSHADOWH
#define NOSHADOWH
#endif
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>
#include <pwd.h>

#ifndef NOSHADOWH
#include <shadow.h>
#endif

/* SunOS apparently needs this for crypt() */
#if defined sun || defined __sun || defined __sun__
#include <crypt.h>
#endif

#include "die.h"
#include "getPassword.h"
#include "warn.h"

#ifndef NOSHADOWH

#define PASSWD_FILE "/etc/shadow"
#define TMPNAME "/etc/shadow.new"

#else

#define PASSWD_FILE "/etc/passwd"
#define TMPNAME "/etc/passwd.new"

#endif

int main(int argc, char *argv[])
{
	char password[128], repassword[128];
	char *username = NULL;
	char *stored;
	FILE *tmpf;
	struct passwd *pwd;
#ifndef NOSHADOWH
	struct spwd *spwd;
#endif

	if (argc > 1)
		username = argv[1];

	/* XXX */
	if (username && getuid())
		die("You can't change password for %s\n", username);

	if (!(tmpf = fopen(TMPNAME, "w+"))) {
		perror("fopen()");
		return 1;
	}

	setpwent();

	while ((pwd = getpwent())) {
#ifndef NOSHADOWH
		if (!(spwd = getspnam(pwd->pw_name))) {
			perror("getspnam()");
			continue;
		}

		if (username) {
			if (strcmp(username, pwd->pw_name)) {
				putspent(spwd, tmpf);
				continue;
			}
		} else if (pwd->pw_uid != getuid()) {
			putspent(spwd, tmpf);
			continue;
		}

		stored = spwd->sp_pwdp;
#else
		if (username) {
			if (strcmp(username, pwd->pw_name)) {
				putpwent(pwd, tmpf);
				continue;
			}
		} else if (pwd->pw_uid != getuid()) {
			putpwent(pwd, tmpf);
			continue;
		}

		stored = pwd->pw_passwd;
#endif

		if (strlen(stored)) {
			getPassword("Old Password:", password, sizeof password);

			if (strcmp(crypt(password, stored), stored)) {
				warn("Incorrect password\n");
				fclose(tmpf);
				unlink(TMPNAME);
				return 1;
			}
		}

		getPassword("New Password:", password, sizeof password);

		getPassword("Re-enter new Password:", repassword, sizeof repassword);

		if (strcmp(password, repassword)) {
			warn("Passwords don't match\n");
			fclose(tmpf);
			unlink(TMPNAME);
			return 1;
		}

#ifndef NOSHADOWH
		spwd->sp_pwdp = crypt(password, "aX");
		putspent(spwd, tmpf);
#else
		pwd->pw_passwd = crypt(password, "aX");
		putpwent(pwd, tmpf);
#endif
	}

	fclose(tmpf);

	if (rename(TMPNAME, PASSWD_FILE) == -1) {
		perror("rename()");
		unlink(TMPNAME);
		return 1;
	}

	return 1;
}

