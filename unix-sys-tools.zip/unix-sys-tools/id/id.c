/* id.c - id - 10/16/2006
 *
 * http://unix-sys-tools.sourceforge.net
 *
 * Copyright (C) 2006, 2007 Kris Katterjohn
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

/* for getopt() */
#define _POSIX_SOURCE
#define _POSIX_C_SOURCE 2

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <pwd.h>
#include <grp.h>

/* OpenBSD (3.8, at least) apparently needs this for getopt() */
#ifdef __OpenBSD__
#include <getopt.h>
#endif

#include "dalloc.h"
#include "die.h"

/* meh */
#define GOPT 0x01
#define UOPT 0x02

/* get passwd info using nam if given, else using uid and do error checking */
static struct passwd *getpwd(const char *nam, const uid_t uid)
{
	struct passwd *pwd;

	errno = 0;

	if (nam) {
		if (!(pwd = getpwnam(nam))) {
			if (errno) {
				perror("getpwnam()");
				exit(1);
			}

			die("No such user\n");
		}
		return pwd;
	}

	if (!(pwd = getpwuid(uid))) {
		if (errno) {
			perror("getpwuid()");
			exit(1);
		}

		die("No such user\n");
	}

	return pwd;
}

/* get group info and do error checking */
static struct group *getgrp(const gid_t gid)
{
	struct group *grp;

	errno = 0;

	if (!(grp = getgrgid(gid))) {
		if (errno) {
			perror("getgrgid()");
			exit(1);
		}
		die("No such user\n");
	}

	return grp;
}

int main(int argc, char *argv[])
{
	int groupnum, i;
	int opt = 0;
	char *username = NULL;
	struct group *grp;
	struct passwd *pwd;

	while ((i = getopt(argc, argv, "gu")) != -1) {
		switch (i) {
		case 'g':
			opt |= GOPT;
			break;
		case 'u':
			opt |= UOPT;
			break;
		default:
			break;
		}
	}

	if (optind < argc)
		username = argv[optind];

	if (opt & GOPT) {
		if (username) {
			pwd = getpwd(username, -1);

			printf("%u\n", (unsigned) pwd->pw_gid);
		} else {
			printf("%u\n", (unsigned) getegid());
		}
		return 0;
	}

	if (opt & UOPT) {
		if (username) {
			pwd = getpwd(username, -1);

			printf("%u\n", (unsigned) pwd->pw_uid);
		} else {
			printf("%u\n", (unsigned) geteuid());
		}
		return 0;
	}

	pwd = getpwd(username, getuid());

	printf("uid=%u(%s) ", (unsigned) pwd->pw_uid, pwd->pw_name);

	if ((grp = getgrp(pwd->pw_gid)))
		printf("gid=%u(%s) ", (unsigned) grp->gr_gid, grp->gr_name);

	if (username)
		goto end;

	if (getuid() != geteuid()) {
		if ((pwd = getpwd(NULL, geteuid())))
			printf("euid=%u(%s) ", (unsigned) pwd->pw_uid, pwd->pw_name);
	}

	if (getgid() != getegid()) {
		if ((grp = getgrp(pwd->pw_gid)))
			printf("egid=%u(%s) ", (unsigned) grp->gr_gid, grp->gr_name);
	}

	if ((groupnum = getgroups(0, NULL)) > 0) {
		gid_t *groups;

		groups = dalloc(groupnum * sizeof(gid_t));

		if (getgroups(groupnum, groups) == -1) {
			perror("getgroups()");
			goto end;
		}

		grp = getgrp(groups[0]);

		printf("groups=%u(%s)", (unsigned) grp->gr_gid, grp->gr_name);

		for (i = 1; i < groupnum; i++) {
			grp = getgrp(groups[i]);

			printf(",%u(%s)", (unsigned) grp->gr_gid, grp->gr_name);
		}

		free(groups);
	} else if (groupnum == -1) {
		perror("getgroups()");
	}

end:
	putchar('\n');

	return 0;
}

