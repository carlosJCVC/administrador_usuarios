/* chsh.c - chsh - 10/29/2006
 *
 * http://unix-sys-tools.sourceforge.net
 *
 * Copyright (C) 2006, 2007 Kris Katterjohn
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

/* for crypt() (NetBSD and SunOS apparently need this set >= 4) */
#define _XOPEN_SOURCE 4

/* for putpw*() */
#define _SVID_SOURCE

/* (Dragonfly|Free|Net|Open)BSD, BSD/OS, and Mac OS X use the getpw*() functions
 * to return the encrypted passwords instead of the getsp*() functions when
 * shadowing is used. You just have to be root (or sometimes be in the _shadow
 * group) to get it
 */
#if defined __FreeBSD__ || defined __NetBSD__ || defined __OpenBSD__ || \
    defined __DragonFly__ || defined __bsdi__ || defined __APPLE__
#ifndef NOSHADOWH
#define NOSHADOWH
#endif
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>
#include <pwd.h>

#ifndef NOSHADOWH
#include <shadow.h>
#endif

/* SunOS apparently needs this for crypt() */
#if defined sun || defined __sun || defined __sun__
#include <crypt.h>
#endif

#include "chomp.h"
#include "die.h"
#include "getPassword.h"
#include "warn.h"

#define PASSWD_FILE "/etc/passwd"
#define TMPNAME "/etc/passwd.new"

/* read shell from stdin */
static void getNewShell(char *buf, const size_t len, const char *oshell)
{
	do {
		printf("\tLogin Shell [%s]: ", oshell);
		fflush(stdout);
	} while (read(STDIN_FILENO, buf, len) <= 0);

	chomp(buf);
}

int main(int argc, char *argv[])
{
	int c;
	char password[128], shell[24];
	char *username = NULL;
	char *stored;
	FILE *tmpf;
	struct passwd *pwd;
#ifndef NOSHADOWH
	struct spwd *spwd;
#endif

	shell[0] = '\0';

	while ((c = getopt(argc, argv, "s:")) != -1) {
		switch (c) {
		case 's':
			strncpy(shell, optarg, sizeof shell);
			break;
		default:
			break;
		}
	}

	if (optind < argc)
		username = argv[optind];

	if (username && getuid())
		die("You can't change the shell for %s\n", username);

	if (!(tmpf = fopen(TMPNAME, "w+"))) {
		perror("fopen()");
		return 1;
	}

	setpwent();

	while ((pwd = getpwent())) {
		if (username) {
			if (strcmp(username, pwd->pw_name))
				goto end;
		} else if (pwd->pw_uid != getuid())
			goto end;

		if (!getuid())
			goto authenticated;

#ifndef NOSHADOWH
		if (!(spwd = getspnam(pwd->pw_name)))
			stored = pwd->pw_passwd;
		else
			stored = spwd->sp_pwdp;
#else
		/* If we're not using shadow passwords or we're running on a BSD */
		stored = pwd->pw_passwd;
#endif

		if (strlen(stored)) {
			getPassword("Password:", password, sizeof password);

			if (strcmp(crypt(password, stored), stored)) {
				warn("Incorrect password\n");
				fclose(tmpf);
				unlink(TMPNAME);
				return 1;
			}
		}

authenticated:
		if (!strlen(pwd->pw_shell))
			pwd->pw_shell = "/bin/sh";

		if (!strlen(shell)) {
			printf("Changing shell for %s\n", pwd->pw_name);
			printf("Enter new value or press ENTER to use default\n\n");
			getNewShell(shell, sizeof shell, pwd->pw_shell);
		}

		pwd->pw_shell = shell;
end:
		putpwent(pwd, tmpf);
	}

	fclose(tmpf);

	if (rename(TMPNAME, PASSWD_FILE) == -1) {
		perror("rename()");
		unlink(TMPNAME);
		return 1;
	}

	return 0;
}

